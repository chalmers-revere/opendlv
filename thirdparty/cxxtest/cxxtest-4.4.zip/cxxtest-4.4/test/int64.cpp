//
// This program is used to check if the compiler supports __int64
//
int main()
{
    __int64 ll = 0;
    return (int)ll;
}
