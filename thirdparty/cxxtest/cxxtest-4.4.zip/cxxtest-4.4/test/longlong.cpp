//
// This program is used to check if the compiler supports "long long"
//
int main()
{
    long long ll = 0;
    return (int)ll;
}
