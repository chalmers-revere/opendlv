#ifndef __GUI_WAIT_H
#define __GUI_WAIT_H

#define CXXTEST_SAMPLE_GUI_WAIT()

#endif // __GUI_WAIT_H
