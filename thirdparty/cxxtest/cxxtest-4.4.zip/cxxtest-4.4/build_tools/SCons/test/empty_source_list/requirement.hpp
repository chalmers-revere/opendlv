/**
 * @file requirement.cpp
 * Implementation of the requirement function.
 *
 * @author Gašper Ažman (GA), gasper.azman@gmail.com
 * @version 1.0
 * @since 2008-08-29 10:09:42 AM
 */

bool call_a_requirement() {
    return true;
}
