CxxTest Python Package
======================

The CxxTest Python package includes utilities that are used by the
CxxTest unit testing framework.  Specifically, this Python package
supports C++ parsing and code generation done in the cxxtestgen 
script.

